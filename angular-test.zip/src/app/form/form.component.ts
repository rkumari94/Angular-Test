import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material'
import { PreviewComponent } from '../preview/preview.component';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit, OnChanges {
  @Output() toggleForm = new EventEmitter();
  @Output() toggleFormFalse = new EventEmitter();
  @Input() pushData;

  details = [];

  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }
  compare (a,b){
    const bandA = a.orderId;
  const bandB = b.orderId;

  let comparison = 0;
  if (bandA > bandB) {
    comparison = 1;
  } else if (bandA < bandB) {
    comparison = -1;
  }
  return comparison;
  }

  ngOnChanges() {
    
    if (this.pushData) {
      this.details.push(this.pushData);
      this.details.sort(this.compare);

    }
    // this.details.push(this.pushData);
    console.log("test", this.pushData);
    console.log(this.details);
    this.pushData = '';

  }

  toggle() {
    this.toggleForm.emit(true);
  }

  toggleFalse() {
    this.toggleFormFalse.emit(false);
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(PreviewComponent, {
      data: this.details
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
}
