import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { UpdateField } from '../update'

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  @Output() closeField = new EventEmitter();
  @Output() pushData = new EventEmitter();

  update = new UpdateField;
  submitted = false;
  dropDown = "Text Field";
  uniqueId = (Date.now())%100000;
  typeField = [
    { value: 'Text Field', viewValue: 'Text Field' },
    { value: 'Text Area', viewValue: 'Text Area' },
    { value: 'Dropdown', viewValue: 'Dropdown' },
    { value: 'MultiSelect', viewValue: 'MultiSelect' },
    { value: 'Checkbox', viewValue: 'Checkbox' },
  ];

  constructor() { }

  ngOnInit() {
  }

  close() {
    this.closeField.emit(false);
  }

  onSubmit(filled: any) {
    this.submitted = true;
    this.pushData.emit({
      uniqueId: this.uniqueId,
      orderId: filled.orderId,
      name: filled.name,
      type: this.dropDown,
      visible: true,
      required: false
    });
    this.close();
  }
}
