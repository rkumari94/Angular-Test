import {MatButtonModule,MatDialog} from '@angular/material';
import {MatDialogModule} from '@angular/material';
import {NgModule} from '@angular/core';
import { PreviewComponent } from './preview/preview.component';

@NgModule({
    imports : [MatButtonModule,MatDialogModule],
    exports: [MatButtonModule,MatDialogModule]
})


export class MaterialModule{
    constructor(public dialog: MatDialog) {}
 
    openDialog(): void {
        const dialogRef = this.dialog.open(PreviewComponent, {
        
        });
    
        dialogRef.afterClosed().subscribe(result => {
          console.log('The dialog was closed');
        });
      }
}
