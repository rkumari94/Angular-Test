import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import { UpdateComponent } from './update/update.component';
import { PreviewComponent } from './preview/preview.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule,MatSelectModule } from '@angular/material';

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    UpdateComponent,
    PreviewComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    MatDialogModule,
    ReactiveFormsModule,
    MatSelectModule
    

  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents:[
    PreviewComponent
  ]
})
export class AppModule { }
