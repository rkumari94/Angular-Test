import { MatDialog } from '@angular/material';
import { PreviewComponent } from '../app/preview/preview.component'
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'dummy';
  addField = false;
  data;

  constructor(public dialog: MatDialog) { }

  openDialog(): void {
    const dialogRef = this.dialog.open(PreviewComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  toggle(toggleForm: any) {
    this.addField = toggleForm;
  }

  close(closeField: any) {
    this.addField = closeField
  }

  sendData(pushData: any) {
    this.data = pushData;
  }

}
