import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material'
import { Inject } from '@angular/core';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})
export class PreviewComponent implements OnInit {
  dropDown;
  showUpdateForm = false;
  allData = [];

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef<PreviewComponent>) { }

  previewForm = new FormGroup({
    orderId: new FormControl('', Validators.required),
    fieldName: new FormControl('', Validators.required),
    type: new FormControl('', Validators.required)
  });;

  onSubmit() {
    const updatedData = this.previewForm.value;
    for (const data of this.allData) {
      if (data.uniqueId === this.dropDown) {
        data.orderId = updatedData.orderId;
        data.name = updatedData.fieldName;
        data.type = updatedData.type;
        break;
      }
    }
    this.showUpdateForm = false;
  }

  selectedId() {
    for (const data of this.allData) {
      if (data.uniqueId === this.dropDown) {
        this.previewForm.patchValue({
          orderId: data.orderId,
          fieldName: data.name,
          type: data.type
        });
        break;
      }
    }
    this.showUpdateForm = true;
  }

  cancel() {
    this.showUpdateForm = false;
  }

  close() {
    this.dialogRef.close();
  }

  ngOnInit() {
    this.allData = this.data;
    if (this.allData.length > 0) {
      this.dropDown = this.allData[0].uniqueId;
    }
  }

}
