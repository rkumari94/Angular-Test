export class UpdateField {
    orderId: number;
    name : string;
    type: string;
    visible: boolean;
    required: boolean


}
